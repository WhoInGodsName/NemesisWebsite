# Nemesis 1.3.2 by Full Name Unknown

Nemesis V1.3.2 is a modification for the game Deep Rock Galactic.  This Mod can be used to enhance gameplay to your liking or help with that one mission you just cant quite finish.

## Installation

1) Download the zip file and extract it. <br>

2) If you have a previous version make sure to uninstall it using "Add or remove programs". <br>

3) Open Deep Rock Galactic prior to running the Deepcoc executable <br>
 
if you are having trouble running the executable try running as administrator or check 
https://www.unknowncheats.me/forum/other-fps-games/603417-deep-rock-galactic-nemesis-name-unknown.html 
for a new update.

## Usage

### Fly
Spacebar is used to ascend and SHIFT is used to descend.  Fly speed can be increased or decreased by using the "Fly Speed" slider.

### Carve 'er up
This allows for the user to input an integer value for the radius of terrain destruction caused by the primary guns bullets, test out this feature by setting the value to 1000, activating it and then shooting a wall.

### Character size changing

Character size changing works locally for both hosts and clients but will not be seen by the other players unless the host uses it before the other players join the party OR if using the step by step process explained below. <br>

1. Start a mission <br>
2. As you load into the mission and the drill starts to approach the ground click the resize button a couple times with the size you want to be for the mission <br>
3. profit, anyone can now see that size if they are in/join the mission! <br>

### Lock Firerate and full auto
Some guns will work differently with lock firerate and full auto.  A general rule of thumb is if the gun is already full auto, do not use the full auto feature on that gun as it may mess with its firerate.  Locking the firerate will work on all or most weapons.

### Mollys Pockets
This feature allows the changing of the values of resources that have been deposited already, this feature will not work for mission resource values such as morkite.  These values will be added to your account when the match has finished so make sure you would like to have 999999999 (or whatever value you have set it as) enor pearls before you end the match with that value.

### Sticky Fingers (Marry Poppins)
This feature allows you to freeze the first resource value you are currently carrying meaning that you can deposit that resource infinitely, to deactivate this feature click on "ANTI POPPINS".


## More Help
If you have further questions or suggestions please express them to me on UC, thankyou :)